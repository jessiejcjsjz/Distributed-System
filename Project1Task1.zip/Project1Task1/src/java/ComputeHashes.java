

import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;

/**
 *
 * @author Jiani Shen, AndrewID: jianis1
 */


//set the servlet and pattern here , same as the web.xml setting
@WebServlet(name = "IHashes",
        urlPatterns = {"/getHashes"})
public class ComputeHashes extends HttpServlet {

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         //get the input parameter if exists
        String word = request.getParameter("hashWord");
        //get the hashway choice if exists
        String way = request.getParameter("hashWay");
        //create wordhex to store hex code
        String wordhex = null;
        //create wordbast64 to store base 64 code
        String wordbase64 = null;
        
        //check to use which hash way
        
        if (way.equals("MD5")){
            MessageDigest md;   //create an object of MessageDigetst
            try {
                md = MessageDigest.getInstance("MD5"); //choose algorithm as MD5 to digest
                md.update(word.getBytes()); // data is proceeded througth
                byte[] secret = md.digest(); //performs a final update on the digest using the specified array of bytes, then completes the digest computation.
                wordbase64 = DatatypeConverter.printBase64Binary(secret); //convert information by using base64
                wordhex = DatatypeConverter.printHexBinary(secret); //convert information by using hex
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(ComputeHashes.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        if(way.equals("SHA-1")){
            MessageDigest md1;  //create an object of MessageDigetst
            try {
                md1 = MessageDigest.getInstance("SHA-1"); //choose algorithm as SHA-1 to digest
                md1.update(word.getBytes()); // data is proceeded througth
                byte[] secret = md1.digest(); //performs a final update on the digest using the specified array of bytes, then completes the digest computation.
                wordbase64 = DatatypeConverter.printBase64Binary(secret); //convert information by using base64
                wordhex = DatatypeConverter.printHexBinary(secret); //convert information by using hex
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(ComputeHashes.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        //print the output to the browser
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ComputeHashes</title>");            
            out.println("</head>");
            out.println("<body>");
            //if the there's informaion in wordhex and in wordbase64 then display the result, else ask user to try again
            if(wordhex != null & wordbase64 != null){
                out.println("<h1>Original word : "  + word);
                out.println("<h1>" + way + "(hex): " + wordhex + "</h1>");
                out.println("<h1>" + way + "(Base 64):" + wordbase64 + "</h1>");
            }else{
                out.println("<h1>Sorry, please try again</h1>");
            }
            out.println("</body>");
            out.println("</html>");
        }
    }
}